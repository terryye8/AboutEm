import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills"){
                    Text("Marketing")
                    Text("Design")
                    Text("Writing")
                }
                
                Section("Language"){
                    Text("English")
                }
            }
            
        
        }
        .navigationTitle("More Info")
    }
}

#Preview(
    body: { 
        ContentView()
    })


