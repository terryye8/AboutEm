import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            Tab("About",systemImage:"person"){
                AboutView()
            }
            Tab("Contact",systemImage:"phone"){
                ContactView()
            }
            Tab("More",systemImage:"ellipsis"){
                MoreView()
            }
        }    
    }
}

#Preview(
    body: { 
    ContentView()
})

