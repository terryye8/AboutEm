import SwiftUI

struct AboutView: View {
    let hobbies = ["board games", "sleeping"]
    var body: some View {
        ZStack {
            Color.green
                .opacity(0.30)
                .background(ignoresSafeAreaEdges: .all)
            VStack { //Z stack would make foreground background
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(30)
                    .shadow(color: .green, radius: 20)
                    .padding()
                //Image(systemName: "globe")
                //.imageScale(.large)
                //  .foregroundColor(.accentColor)
                Text("Max Chow Everett")
                //Text("Hello, world!")
                    .font(.largeTitle)
                    .bold()
                
                Text("I love board \(hobbies.formatted())")
                HStack(content: {
                    Image(systemName: "iphone")
                    Image(systemName: "airpods.pro")
                    Image(systemName: "macbook")
                    Image(systemName: "ipod.shuffle.gen4")
                })
                .imageScale(.large)
                .padding()
                
                
                Text("Fun Fact")
                    .bold()
                    .font(.title)
                Text("I can juggle")
                
                Spacer()
                    .frame(height: 20)
                
                Text("Favorite Apple Product")
                    .bold()
                    .font(.title)
                Text("The Airpods")
                
                
            }
            .multilineTextAlignment(.center)
            .padding()
            .fontDesign(.default)
        }
    }
}

#Preview(
    body: { 
        ContentView()
    })


