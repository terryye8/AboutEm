import SwiftUI

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack {
            VStack { //Z stack would make foreground background
                Link(destination: URL(string: "instagram.com/")!, label: {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                })
                .buttonBorderShape(.roundedRectangle(radius:20))
                .buttonStyle(.borderedProminent)
            }
        }
        .navigationTitle("Contact")
    }
}

#Preview(
    body: { 
        ContentView()
    })

